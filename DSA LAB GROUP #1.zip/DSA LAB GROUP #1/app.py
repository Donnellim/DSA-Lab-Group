from flask import Flask, render_template, request, redirect, url_for
from Link import LinkedList

app = Flask(__name__)

linked_list = LinkedList()

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/profile')
def profile():
    return render_template('profile.html')

@app.route('/works', methods=['GET', 'POST'])
def works():
    result = None
    if request.method == 'POST':
        input_string = request.form.get('inputString', '')
        result = input_string.upper()
    return render_template('touppercase.html', result=result)

@app.route('/contact')
def contact():
    return "Contact Page. Please create me an HTML page with dummy contact info."

@app.route('/linkedlist', methods=['GET', 'POST'])
def linkedlist():
    message = None
    linked_list_elements = linked_list.print_list()
    if request.method == 'POST':
        action = request.form.get('action')
        data = request.form.get('data', '')

        if action == 'insert_beginning':
            linked_list.insert_at_beginning(data)
            message = f"Inserted '{data}' at the beginning."
        elif action == 'insert_end':
            linked_list.insert_at_end(data)
            message = f"Inserted '{data}' at the end."
        elif action == 'search':
            found = linked_list.search(data)
            message = f"'{data}' is {'found' if found else 'not found'} in the list."
        elif action == 'remove_beginning':
            message = linked_list.remove_at_beginning() or "Removed the first element."
        elif action == 'remove_end':
            message = linked_list.remove_at_end() or "Removed the last element."
        elif action == 'remove_at':
            message = linked_list.remove_at(data)

        linked_list_elements = linked_list.print_list()

    return render_template('linkedlist.html', message=message, elements=linked_list_elements)

if __name__ == "__main__":
    app.run(debug=True)
    