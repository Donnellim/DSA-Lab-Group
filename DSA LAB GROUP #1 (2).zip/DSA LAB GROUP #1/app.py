from flask import Flask, render_template, request, redirect, url_for, jsonify, send_file
from Link import LinkedList
import matplotlib
matplotlib.use('Agg')  # Use a non-interactive backend
import matplotlib.pyplot as plt
import networkx as nx
import heapq
import os
import io


app = Flask(__name__)

linked_list = LinkedList()

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/profile')
def profile():
    return render_template('profile.html')

@app.route('/works', methods=['GET', 'POST'])
def works():
    result = None
    if request.method == 'POST':
        input_string = request.form.get('inputString', '')
        result = input_string.upper()
    return render_template('touppercase.html', result=result)

@app.route('/contact')
def contact():
    return "Contact Page. Please create me an HTML page with dummy contact info."

@app.route('/linkedlist', methods=['GET', 'POST'])
def linkedlist():
    message = None
    linked_list_elements = linked_list.print_list()
    if request.method == 'POST':
        action = request.form.get('action')
        data = request.form.get('data', '')

        if action == 'insert_beginning':
            linked_list.insert_at_beginning(data)
            message = f"Inserted '{data}' at the beginning."
        elif action == 'insert_end':
            linked_list.insert_at_end(data)
            message = f"Inserted '{data}' at the end."
        elif action == 'search':
            found = linked_list.search(data)
            message = f"'{data}' is {'found' if found else 'not found'} in the list."
        elif action == 'remove_beginning':
            message = linked_list.remove_at_beginning() or "Removed the first element."
        elif action == 'remove_end':
            message = linked_list.remove_at_end() or "Removed the last element."
        elif action == 'remove_at':
            message = linked_list.remove_at(data)

        linked_list_elements = linked_list.print_list()

    return render_template('linkedlist.html', message=message, elements=linked_list_elements)

lines = {
    "MRT Line 3": [
        "North Avenue", "Quezon Avenue", "Kamuning", "Cubao",
        "Santolan", "Ortigas", "Shaw Boulevard", "Boni",
        "Guadalupe", "Buendia", "Ayala", "Magallanes", "Taft"
    ],
    "LRT Line 1": [
        "Dr. Santos", "Ninoy Aquino", "PITX", "MIA Road", "Redemptionist", "Baclaran", 
        "EDSA", "Libertad", "Gil Puyat", "Vito Cruz", "Quirino", 
        "Pedro Gil", "United Nations", "Central Terminal", "Carriedo", 
        "D. Jose", "Blumentritt", "Tayuman", "Bambang", "Monumento", 
        "Balintawak", "Roosevelt"
    ],
    "LRT Line 2": [
        "Recto", "Legarda", "Pureza", "V. Mapa", "J. Ruiz", "Gilmore",
        "Betty Go-Belmonte", "Cubao", "Anonas", "Katipunan", "Santolan", "Antipolo"
    ]
}

# Create the graph
graph = nx.Graph()

# Add edges for each line
for line, stations in lines.items():
    for i in range(len(stations) - 1):
        graph.add_edge(stations[i], stations[i + 1], line=line, weight=1)

# Add interconnections between lines
# 1. LRT 1 Roosevelt to MRT 3 North Avenue
graph.add_edge("Roosevelt", "North Avenue", line="Connection", weight=1)

# 2. LRT 1 EDSA to MRT 3 Taft
graph.add_edge("EDSA", "Taft", line="Connection", weight=1)

# 3. LRT 1 Doroteo Jose to LRT 2 Recto
graph.add_edge("D. Jose", "Recto", line="Connection", weight=1)

# 4. Reverse directions are naturally handled in undirected graphs

@app.route('/TrainStations')
def TrainStations():
    return render_template('TrainStations.html', stations=graph.nodes)


@app.route('/shortest_path', methods=['POST'])
def shortest_path():
    start = request.form['start']
    end = request.form['end']

    # Calculate the shortest path
    shortest_path = nx.shortest_path(graph, source=start, target=end, weight='weight')

    # Generate the visualization
    plt.figure(figsize=(14, 10))
    pos = nx.spring_layout(graph, seed=42)
    nx.draw(graph, pos, with_labels=True, node_size=800, node_color="lightblue", font_size=10)

    path_edges = list(zip(shortest_path, shortest_path[1:]))
    nx.draw_networkx_nodes(graph, pos, nodelist=shortest_path, node_color="orange", node_size=800)
    nx.draw_networkx_edges(graph, pos, edgelist=path_edges, edge_color="red", width=2)
    plt.title(f"Shortest Path from {start} to {end}")

    # Save the plot to a BytesIO stream
    img = io.BytesIO()
    plt.savefig(img, format='png')
    img.seek(0)
    plt.close()

    return send_file(img, mimetype='image/png')


if __name__ == '__main__':
    app.run(debug=True)