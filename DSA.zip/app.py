from flask import Flask, render_template, request, redirect, url_for
from Link import LinkedList

app = Flask(__name__)

linked_list = LinkedList()

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/profile')
def profile():
    return render_template('profile.html')

@app.route('/works', methods=['GET', 'POST'])
def works():
    result = None
    if request.method == 'POST':
        input_string = request.form.get('inputString', '')
        result = input_string.upper()
    return render_template('touppercase.html', result=result)

@app.route('/contact')
def contact():
    return "Contact Page. Please create me an HTML page with dummy contact info."

@app.route('/linkedlist', methods=['GET', 'POST'])
def LinkedList():
    return render_template('linkedlist.html', elements=linked_list.display())

@app.route('/append', methods=['POST'])
def append():
    data = request.form.get('data')
    if data:
        linked_list.append(data)
    return redirect(url_for('LinkedList'))

@app.route('/remove_beginning', methods=['POST'])
def remove_beginning():
    removed_data = linked_list.remove_beginning()
    return redirect(url_for('LinkedList'))

@app.route('/remove_at_end', methods=['POST'])
def remove_at_end():
    removed_data = linked_list.remove_at_end()
    return redirect(url_for('LinkedList'))

@app.route('/remove_at', methods=['POST'])
def remove_at():
    data = request.form.get('data')
    if data:
        linked_list.remove_at(data)
    return redirect(url_for('LinkedList'))

@app.route('/search', methods=['POST'])
def search():
    data = request.form.get('data')
    search_result = linked_list.search(data)
    return render_template('linkedlist.html', elements=linked_list.display(), search_result=search_result)

if __name__ == "__main__":
    app.run(debug=True)
    