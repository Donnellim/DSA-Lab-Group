document.getElementById('sortButton').addEventListener('click', async () => {
    const numbersInput = document.getElementById('numbers').value;
    const algorithm = document.getElementById('algorithm').value;
    const numbers = numbersInput.split(',').map(num => parseInt(num.trim())).filter(num => !isNaN(num));

    // Clear previous bars
    const container = document.getElementById('array-container');
    container.innerHTML = '';

    // Create initial bars
    numbers.forEach(value => {
        const bar = document.createElement('div');
        bar.style.height = `${value * 3}px`;
        bar.className = 'bar';
        container.appendChild(bar);
    });

    // Call the sorting function
    await sortAndVisualize(numbers, algorithm);
});

async function sortAndVisualize(numbers, algorithm) {
    switch (algorithm) {
        case 'bubble':
            await bubbleSort(numbers);
            break;
        case 'selection':
            await selectionSort(numbers);
            break;
        case 'insertion':
            await insertionSort(numbers);
            break;
        case 'merge':
            await mergeSort(numbers);
            break;
        case 'quick':
            await quickSort(numbers);
            break;
    }
}

async function bubbleSort(arr) {
    const n = arr.length;
    for (let i = 0; i < n - 1; i++) {
        for (let j = 0; j < n - i - 1; j++) {
            if (arr[j] > arr[j + 1]) {
                // Swap
                [arr[j], arr[j + 1]] = [arr[j + 1], arr[j]];
                await visualizeArray(arr);
            }
        }
    }
}

async function selectionSort(arr) {
    const n = arr.length;
    for (let i = 0; i < n - 1; i++) {
        let minIndex = i;
        for (let j = i + 1; j < n; j++) {
            if (arr[j] < arr[minIndex]) {
                minIndex = j;
            }
        }
        // Swap
        [arr[i], arr[minIndex]] = [arr[minIndex], arr[i]];
        await visualizeArray(arr);
    }
}

async function insertionSort(arr) {
    for (let i = 1; i < arr.length; i++) {
        let key = arr[i];
        let j = i - 1;
        while (j >= 0 && arr[j] > key) {
            arr[j + 1] = arr[j];
            j--;
            await visualizeArray(arr);
        }
        arr[j + 1] = key;
        await visualizeArray(arr);
    }
}

async function mergeSort(arr) {
    await mergeSortHelper(arr, 0, arr.length - 1);
}

async function mergeSortHelper(arr, left, right) {
    if (left < right) {
        const mid = Math.floor((left + right) / 2);
        await mergeSortHelper(arr, left, mid);
        await mergeSortHelper(arr, mid + 1, right);
        await merge(arr, left, mid, right);
    }
}

async function merge(arr, left, mid, right) {
    const leftArray = arr.slice(left, mid + 1);
    const rightArray = arr.slice(mid + 1, right + 1);
    let i = 0, j = 0, k = left;

    while (i < leftArray.length && j < rightArray.length) {
        if (leftArray[i] <= rightArray[j]) {
            arr[k++] = leftArray[i++];
        } else {
            arr[k++] = rightArray[j++];
        }
    }
    while (i < leftArray.length) {
        arr[k++] = leftArray[i++];
    }
    while (j < rightArray.length) {
        arr[k++] = rightArray[j++];
    }
    await visualizeArray(arr);
}

async function quickSort(arr) {
    await quickSortHelper(arr, 0, arr.length - 1);
}

async function quickSortHelper(arr, low, high) {
    if (low < high) {
        const partitionIndex = await partition(arr, low, high);
        await quickSortHelper(arr, low, partitionIndex - 1);
        await quickSortHelper(arr, partitionIndex + 1, high);
    }
}

async function partition(arr, low, high) {
    const pivot = arr[high];
    let i = low - 1;
    for (let j = low; j < high; j++) {
        if (arr[j] < pivot) {
            i++;
            [arr[i], arr[j]] = [arr[j], arr[i]];
            await visualizeArray(arr);
        }
    }
    [arr[i + 1], arr[high]] = [arr[high], arr[i + 1]];
    await visualizeArray(arr);
    return i + 1;
}

async function visualizeArray(arr) {
    const container = document.getElementById('array-container');
    container.innerHTML = '';
    arr.forEach(value => {
        const bar = document.createElement('div');
        bar.style.height = `${value * 3}px`;
        bar.className = 'bar';
        container.appendChild(bar);
    });
    await new Promise(resolve => setTimeout(resolve, 500)); // Delay for visualization
}